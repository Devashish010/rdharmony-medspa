# RD Harmony Med Spa — Vercel Deployment

## Files
- `index.html` — Full website (all pages, booking system, admin panel)
- `vercel.json` — Vercel configuration

## Deploy to Vercel (3 Methods)

---

### ✅ Method 1: Drag & Drop (Easiest — No CLI needed)

1. Go to **https://vercel.com**
2. Sign up / Log in (free account)
3. Click **"Add New Project"**
4. Click **"Browse"** or drag the entire `rdharmony-deploy` folder
5. Click **"Deploy"**
6. Done! Your site is live at `https://rdharmony-medspa.vercel.app`

---

### ✅ Method 2: Vercel CLI

```bash
# Install Vercel CLI
npm install -g vercel

# Go to project folder
cd rdharmony-deploy

# Deploy
vercel

# Follow prompts:
# - Set up and deploy? Y
# - Which scope? (your account)
# - Link to existing project? N
# - Project name: rdharmony-medspa
# - Directory: ./
# - Override settings? N
```

---

### ✅ Method 3: GitHub + Vercel (Auto-deploy on push)

1. Create a GitHub repo (e.g., `rdharmony-medspa`)
2. Upload `index.html` and `vercel.json` to it
3. Go to **https://vercel.com/new**
4. Import your GitHub repo
5. Click **Deploy**
6. Every push to GitHub auto-deploys!

---

## Admin Access
- URL: Click "Admin ↗" in the nav
- Email: `admin@rdharmony.com`
- Password: `admin123`

## Custom Domain (Optional)
After deploy on Vercel:
1. Go to Project → Settings → Domains
2. Add your domain (e.g., `rdharmonymedspa.com`)
3. Update DNS at your domain registrar:
   - Add CNAME: `www` → `cname.vercel-dns.com`
   - Add A record: `@` → `76.76.21.21`
